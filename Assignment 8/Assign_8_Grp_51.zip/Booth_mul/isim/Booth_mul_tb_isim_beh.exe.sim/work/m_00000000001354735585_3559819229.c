/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/student/Desktop/a/Booth_mul/Booth_mul.v";
static int ng1[] = {0, 0};
static int ng2[] = {5, 0};
static unsigned int ng3[] = {1U, 0U};
static int ng4[] = {11, 0};
static int ng5[] = {6, 0};
static unsigned int ng6[] = {2U, 0U};
static int ng7[] = {1, 0};



static void Initial_34_0(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(35, ng0);

LAB2:    xsi_set_current_line(36, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2248);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 6);
    xsi_set_current_line(37, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2568);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 6);
    xsi_set_current_line(38, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2088);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 12);
    xsi_set_current_line(39, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2408);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_45_1(char *t0)
{
    char t13[8];
    char t14[8];
    char t15[8];
    char t41[8];
    char t42[8];
    char t43[8];
    char t44[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t16;
    char *t17;
    int t18;
    char *t19;
    int t20;
    int t21;
    char *t22;
    int t23;
    int t24;
    int t25;
    unsigned int t26;
    int t27;
    int t28;
    char *t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t40;
    char *t45;
    char *t46;
    char *t47;
    char *t48;
    char *t49;
    char *t50;
    unsigned int t51;
    char *t52;
    unsigned int t53;
    char *t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    int t59;

LAB0:    t1 = (t0 + 3736U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(45, ng0);
    t2 = (t0 + 4056);
    *((int *)t2) = 1;
    t3 = (t0 + 3768);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(46, ng0);

LAB5:    xsi_set_current_line(47, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:    xsi_set_current_line(55, ng0);

LAB10:    xsi_set_current_line(56, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t3);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB11;

LAB12:    xsi_set_current_line(63, ng0);

LAB17:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2408);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 2088);
    t11 = (t5 + 56U);
    t12 = *((char **)t11);
    memset(t14, 0, 8);
    t16 = (t14 + 4);
    t17 = (t12 + 4);
    t6 = *((unsigned int *)t12);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t17);
    t10 = (t9 >> 0);
    t26 = (t10 & 1);
    *((unsigned int *)t16) = t26;
    xsi_vlogtype_concat(t13, 2, 2, 2U, t14, 1, t4, 1);

LAB18:    t19 = ((char*)((ng3)));
    t18 = xsi_vlog_unsigned_case_compare(t13, 2, t19, 2);
    if (t18 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng6)));
    t18 = xsi_vlog_unsigned_case_compare(t13, 2, t2, 2);
    if (t18 == 1)
        goto LAB21;

LAB22:
LAB23:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 0);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t11);
    t10 = (t9 >> 0);
    t26 = (t10 & 1);
    *((unsigned int *)t5) = t26;
    t12 = (t0 + 2408);
    xsi_vlogvar_assign_value(t12, t14, 0, 0, 1);
    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    memset(t14, 0, 8);
    xsi_vlog_unsigned_rshift(t14, 12, t4, 12, t5, 32);
    t11 = (t0 + 2088);
    xsi_vlogvar_assign_value(t11, t14, 0, 0, 12);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2088);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t14, 0, 8);
    t5 = (t14 + 4);
    t11 = (t4 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (t6 >> 10);
    t8 = (t7 & 1);
    *((unsigned int *)t14) = t8;
    t9 = *((unsigned int *)t11);
    t10 = (t9 >> 10);
    t26 = (t10 & 1);
    *((unsigned int *)t5) = t26;
    t12 = (t0 + 2088);
    t16 = (t0 + 2088);
    t17 = (t16 + 72U);
    t19 = *((char **)t17);
    t22 = ((char*)((ng4)));
    xsi_vlog_generic_convert_bit_index(t15, t19, 2, t22, 32, 1);
    t29 = (t15 + 4);
    t33 = *((unsigned int *)t29);
    t18 = (!(t33));
    if (t18 == 1)
        goto LAB30;

LAB31:
LAB13:
LAB8:    goto LAB2;

LAB6:    xsi_set_current_line(48, ng0);

LAB9:    xsi_set_current_line(49, ng0);
    t11 = ((char*)((ng1)));
    t12 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t12, t11, 0, 0, 6, 0LL);
    xsi_set_current_line(50, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 6, 0LL);
    xsi_set_current_line(51, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2088);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 12);
    xsi_set_current_line(52, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2408);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB8;

LAB11:    xsi_set_current_line(57, ng0);

LAB14:    xsi_set_current_line(58, ng0);
    t4 = (t0 + 1528U);
    t5 = *((char **)t4);
    t4 = (t0 + 2248);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 6, 0LL);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 6, 0LL);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t0 + 2088);
    t4 = (t0 + 2088);
    t5 = (t4 + 72U);
    t11 = *((char **)t5);
    t12 = ((char*)((ng2)));
    t16 = ((char*)((ng1)));
    xsi_vlog_convert_partindices(t13, t14, t15, ((int*)(t11)), 2, t12, 32, 1, t16, 32, 1);
    t17 = (t13 + 4);
    t6 = *((unsigned int *)t17);
    t18 = (!(t6));
    t19 = (t14 + 4);
    t7 = *((unsigned int *)t19);
    t20 = (!(t7));
    t21 = (t18 && t20);
    t22 = (t15 + 4);
    t8 = *((unsigned int *)t22);
    t23 = (!(t8));
    t24 = (t21 && t23);
    if (t24 == 1)
        goto LAB15;

LAB16:    goto LAB13;

LAB15:    t9 = *((unsigned int *)t15);
    t25 = (t9 + 0);
    t10 = *((unsigned int *)t13);
    t26 = *((unsigned int *)t14);
    t27 = (t10 - t26);
    t28 = (t27 + 1);
    xsi_vlogvar_assign_value(t2, t3, t25, *((unsigned int *)t14), t28);
    goto LAB16;

LAB19:    xsi_set_current_line(65, ng0);

LAB24:    xsi_set_current_line(66, ng0);
    t22 = (t0 + 2088);
    t29 = (t22 + 56U);
    t30 = *((char **)t29);
    memset(t15, 0, 8);
    t31 = (t15 + 4);
    t32 = (t30 + 4);
    t33 = *((unsigned int *)t30);
    t34 = (t33 >> 6);
    *((unsigned int *)t15) = t34;
    t35 = *((unsigned int *)t32);
    t36 = (t35 >> 6);
    *((unsigned int *)t31) = t36;
    t37 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t37 & 63U);
    t38 = *((unsigned int *)t31);
    *((unsigned int *)t31) = (t38 & 63U);
    t39 = (t0 + 1688U);
    t40 = *((char **)t39);
    memset(t41, 0, 8);
    xsi_vlog_unsigned_add(t41, 6, t15, 6, t40, 6);
    t39 = (t0 + 2088);
    t45 = (t0 + 2088);
    t46 = (t45 + 72U);
    t47 = *((char **)t46);
    t48 = ((char*)((ng4)));
    t49 = ((char*)((ng5)));
    xsi_vlog_convert_partindices(t42, t43, t44, ((int*)(t47)), 2, t48, 32, 1, t49, 32, 1);
    t50 = (t42 + 4);
    t51 = *((unsigned int *)t50);
    t20 = (!(t51));
    t52 = (t43 + 4);
    t53 = *((unsigned int *)t52);
    t21 = (!(t53));
    t23 = (t20 && t21);
    t54 = (t44 + 4);
    t55 = *((unsigned int *)t54);
    t24 = (!(t55));
    t25 = (t23 && t24);
    if (t25 == 1)
        goto LAB25;

LAB26:    goto LAB23;

LAB21:    xsi_set_current_line(69, ng0);

LAB27:    xsi_set_current_line(70, ng0);
    t3 = (t0 + 2088);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t14, 0, 8);
    t11 = (t14 + 4);
    t12 = (t5 + 4);
    t6 = *((unsigned int *)t5);
    t7 = (t6 >> 6);
    *((unsigned int *)t14) = t7;
    t8 = *((unsigned int *)t12);
    t9 = (t8 >> 6);
    *((unsigned int *)t11) = t9;
    t10 = *((unsigned int *)t14);
    *((unsigned int *)t14) = (t10 & 63U);
    t26 = *((unsigned int *)t11);
    *((unsigned int *)t11) = (t26 & 63U);
    t16 = (t0 + 1688U);
    t17 = *((char **)t16);
    memset(t15, 0, 8);
    xsi_vlog_unsigned_minus(t15, 6, t14, 6, t17, 6);
    t16 = (t0 + 2088);
    t19 = (t0 + 2088);
    t22 = (t19 + 72U);
    t29 = *((char **)t22);
    t30 = ((char*)((ng4)));
    t31 = ((char*)((ng5)));
    xsi_vlog_convert_partindices(t41, t42, t43, ((int*)(t29)), 2, t30, 32, 1, t31, 32, 1);
    t32 = (t41 + 4);
    t33 = *((unsigned int *)t32);
    t20 = (!(t33));
    t39 = (t42 + 4);
    t34 = *((unsigned int *)t39);
    t21 = (!(t34));
    t23 = (t20 && t21);
    t40 = (t43 + 4);
    t35 = *((unsigned int *)t40);
    t24 = (!(t35));
    t25 = (t23 && t24);
    if (t25 == 1)
        goto LAB28;

LAB29:    goto LAB23;

LAB25:    t56 = *((unsigned int *)t44);
    t27 = (t56 + 0);
    t57 = *((unsigned int *)t42);
    t58 = *((unsigned int *)t43);
    t28 = (t57 - t58);
    t59 = (t28 + 1);
    xsi_vlogvar_assign_value(t39, t41, t27, *((unsigned int *)t43), t59);
    goto LAB26;

LAB28:    t36 = *((unsigned int *)t43);
    t27 = (t36 + 0);
    t37 = *((unsigned int *)t41);
    t38 = *((unsigned int *)t42);
    t28 = (t37 - t38);
    t59 = (t28 + 1);
    xsi_vlogvar_assign_value(t16, t15, t27, *((unsigned int *)t42), t59);
    goto LAB29;

LAB30:    xsi_vlogvar_assign_value(t12, t14, 0, *((unsigned int *)t15), 1);
    goto LAB31;

}


extern void work_m_00000000001354735585_3559819229_init()
{
	static char *pe[] = {(void *)Initial_34_0,(void *)Always_45_1};
	xsi_register_didat("work_m_00000000001354735585_3559819229", "isim/Booth_mul_tb_isim_beh.exe.sim/work/m_00000000001354735585_3559819229.didat");
	xsi_register_executes(pe);
}
